#ifndef WINDOWS_UTILS_H
#define WINDOWS_UTILS_H

#include <string>

#ifdef _WIN32
#include <windows.h>

// Convert UTF-8 string to UTF-16 (std::wstring)
inline std::wstring utf8_to_utf16(const std::string& utf8) {
    if (utf8.empty()) return {};
    int size = MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), -1, nullptr, 0);
    if (size <= 0) return {};
    std::wstring w(size - 1, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, utf8.c_str(), -1, &w[0], size);
    return w;
}

// Write UTF-8 string to console using WriteConsoleW (proper Unicode support)
inline void writeConsoleUtf8(const std::string& utf8_str) {
    std::wstring wstr = utf8_to_utf16(utf8_str);
    if (!wstr.empty()) {
        DWORD written = 0;
        WriteConsoleW(GetStdHandle(STD_OUTPUT_HANDLE),
                     wstr.c_str(),
                     static_cast<DWORD>(wstr.size()),
                     &written,
                     nullptr);
    }
}
// Helper function to escape Windows cmd.exe command
// Handles: paths with spaces, ampersands in URLs, backslashes before quotes
// This function properly escapes commands for use with cmd /c "..."
// 
// CRITICAL: cmd.exe has complex quoting rules:
// 1. Inside "cmd /c "...", inner quotes must be doubled: " becomes ""
// 2. Backslash before quote is treated as escape, so \" ends the quoted string
// 3. To include a literal quote inside a quoted string, we need: "" (doubled quote)
// 4. But backslash-quote \" is interpreted as end of quoted string, so we need to escape backslashes
// 5. Ampersand & is treated as command separator, must be escaped with ^
//
// Solution: 
// 1. First escape backslashes before quotes: \" -> \\"
// 2. Then escape ampersands: & -> ^&
// 3. Finally double all quotes: " -> ""
inline std::string escapeWindowsCommand(const std::string& command) {
    std::string escaped = command;
    
    // Step 1: Escape backslashes before quotes FIRST (prevents path truncation)
    // Replace \" with \\" to prevent cmd.exe from treating \" as end of quoted string
    // This must be done BEFORE doubling quotes, otherwise we'll double quotes that are part of \\"
    size_t pos = 0;
    while ((pos = escaped.find("\\\"", pos)) != std::string::npos) {
        escaped.replace(pos, 2, "\\\\\"");  // \" becomes \\"
        pos += 3; // Move past \\"
    }
    
    // Step 2: Escape ALL ampersands with ^& (before we modify quotes)
    // This prevents & from being treated as command separator by cmd.exe
    pos = 0;
    while ((pos = escaped.find("&", pos)) != std::string::npos) {
        // Only escape if not already escaped
        if (pos == 0 || escaped[pos - 1] != '^') {
            escaped.insert(pos, "^");
            pos += 2; // Move past ^&
        } else {
            pos++; // Already escaped, skip
        }
    }
    
    // Step 3: Double all quotes (cmd.exe requires doubled quotes inside cmd /c "...")
    // CRITICAL FIX: For paths with spaces, we need special handling
    // When we have: -o "C:/path with spaces/%(title)s.%(ext)s"
    // After doubling: -o ""C:/path with spaces/%(title)s.%(ext)s""
    // cmd.exe may interpret the space as an argument separator
    // Solution: Ensure quotes are properly doubled, but be extra careful with paths
    // The key insight: cmd.exe needs doubled quotes, but we must ensure the entire quoted string
    // (including the path with spaces) is treated as one argument
    pos = 0;
    while ((pos = escaped.find("\"", pos)) != std::string::npos) {
        // Check if this quote is part of an escaped backslash-quote sequence (\\")
        // If so, skip it - we've already handled it
        if (pos > 0 && escaped[pos - 1] == '\\') {
            // This is part of \\", skip it
            pos++;
            continue;
        }
        // Double this quote - required by cmd.exe for cmd /c "..."
        // This should work correctly if the path is properly formatted with forward slashes
        escaped.replace(pos, 1, "\"\"");
        pos += 2;
    }
    
    return escaped;
}
#endif

#endif // WINDOWS_UTILS_H

